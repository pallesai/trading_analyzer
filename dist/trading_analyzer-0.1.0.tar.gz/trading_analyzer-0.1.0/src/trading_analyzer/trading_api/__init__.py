"""Trading API module for yfinance integration."""

from .yfinance_client import YFinanceClient

__all__ = ["YFinanceClient"]
