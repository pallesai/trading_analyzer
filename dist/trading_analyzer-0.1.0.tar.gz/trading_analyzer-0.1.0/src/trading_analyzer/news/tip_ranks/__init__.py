"""
TipRanks news client package.
"""

from .client import TipRanksNewsClient

__all__ = ["TipRanksNewsClient"]
