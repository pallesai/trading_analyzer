"""News API module for stock news retrieval."""

from .news_client import NewsClient

__all__ = ["NewsClient"]
