"""
Simple and generic HTTP client package.
"""

from .client import HTTPClient

__version__ = "1.0.0"
__all__ = ["HTTPClient"]
