"""YFinance news client module."""

from .news_client import YFNewsClient

__all__ = ["YFNewsClient"]
